jQuery(document).ready(function($) {
    var ajaxurl = slhm_ajax_object.ajax_url;
    var nonce = slhm_ajax_object.nonce;

    // ----- Start Scan Button -----
    $('#slhm-start-scan-btn').on('click', function() {
        var $button = $(this);
        var $message = $('#slhm-scan-message');
        $message.text('Scanning started... This might take a while.');
        $button.prop('disabled', true).addClass('button-disabled');

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'slhm_start_manual_scan',
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    $message.text(slhm_ajax_object.scan_initiated);
                } else {
                    $message.text(response.data.message || slhm_ajax_object.scan_failed);
                }
            },
            error: function() {
                $message.text(slhm_ajax_object.scan_failed);
            },
            complete: function() {
                $button.prop('disabled', false).removeClass('button-disabled');
                // Consider adding a reload here or a more dynamic update
                // setTimeout(function() { location.reload(); }, 3000); // Reload after 3 seconds for updated results
            }
        });
    });

    // ----- Edit Link Modal -----
    var $editModal = $('#slhm-edit-modal');
    var $editForm = $('#slhm-edit-form');
    var $linkIdField = $('#slhm_link_id');
    var $sourceTypeField = $('#slhm_source_type');
    var $sourceIdField = $('#slhm_source_id');
    var $oldUrlField = $('#slhm_old_url');
    var $newUrlField = $('#slhm_new_url');
    var $editMessage = $('#slhm-edit-message');

    // Open modal when "Edit URL" button is clicked
    $('.wp-list-table').on('click', '.slhm-action-update', function(e) {
        e.preventDefault();
        var $button = $(this);
        $linkIdField.val($button.data('link-id'));
        $oldUrlField.val($button.data('old-url'));
        $newUrlField.val($button.data('old-url')); // Initialize new URL with old URL
        $sourceTypeField.val($button.data('source-type'));
        $sourceIdField.val($button.data('source-id'));
        $editMessage.empty(); // Clear previous messages
        $editModal.show();
    });

    // Close modal when close button or outside is clicked
    $('.slhm-close-button').on('click', function() {
        $editModal.hide();
    });
    $(window).on('click', function(event) {
        if ($(event.target).is($editModal)) {
            $editModal.hide();
        }
    });

    // Handle Edit Form Submission
    $editForm.on('submit', function(e) {
        e.preventDefault();
        var newUrl = $newUrlField.val();
        var oldUrl = $oldUrlField.val(); // Get original URL for comparison

        if (newUrl === oldUrl) {
            $editMessage.text('New URL is the same as the original URL. No change made.');
            return;
        }

        if (confirm(slhm_ajax_object.confirm_update)) {
            $editMessage.text('Updating...');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'slhm_update_link',
                    nonce: nonce,
                    link_id: $linkIdField.val(),
                    new_url: newUrl,
                    source_type: $sourceTypeField.val(),
                    source_id: $sourceIdField.val()
                },
                success: function(response) {
                    if (response.success) {
                        $editMessage.text(response.data.message);
                        // Update the table row dynamically if successful
                        var $row = $('.wp-list-table tr[data-id="' + response.data.link_id + '"]');
                        if ($row.length) {
                            var statusClass = 'slhm-status-ok';
                            var statusText = response.data.new_status;
                            if (response.data.is_broken) {
                                statusClass = 'slhm-status-broken';
                                statusText += ' (Broken)';
                            } else if (response.data.is_redirect) {
                                statusClass = 'slhm-status-redirect';
                                statusText += ' (Redirect)';
                            }

                            $row.find('.column-link_url a').attr('href', newUrl).text(newUrl);
                            $row.find('.column-http_status span').removeClass('slhm-status-ok slhm-status-broken slhm-status-redirect slhm-status-error').addClass(statusClass).text(statusText);

                            // Update redirect info if applicable
                            var $redirectInfo = $row.find('.slhm-redirect-info');
                            if (response.data.is_redirect && response.data.redirect_to) {
                                if ($redirectInfo.length) {
                                    $redirectInfo.find('a').attr('href', response.data.redirect_to).text(response.data.redirect_to);
                                } else {
                                    $row.find('.slhm-link-url-wrapper').append('<br><small class="slhm-redirect-info">' + slhm_ajax_object.redirects_to + ' <a href="' + response.data.redirect_to + '" target="_blank">' + response.data.redirect_to + '</a></small>');
                                }
                            } else {
                                if ($redirectInfo.length) {
                                    $redirectInfo.remove();
                                }
                            }
                            // Close modal after a short delay
                            setTimeout(function() { $editModal.hide(); }, 1500);
                        }
                    } else {
                        $editMessage.text(response.data.message || 'Error updating link.');
                    }
                },
                error: function() {
                    $editMessage.text('AJAX error during update.');
                }
            });
        }
    });

    // ----- Delete Link -----
    $('.wp-list-table').on('click', '.slhm-action-delete', function(e) {
        e.preventDefault();
        var $button = $(this);
        var linkId = $button.data('link-id');
        var sourceType = $button.data('source-type');
        var sourceId = $button.data('source-id');

        if (confirm(slhm_ajax_object.confirm_delete)) {
            $button.text('Removing...').prop('disabled', true).addClass('button-disabled');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'slhm_delete_link',
                    nonce: nonce,
                    link_id: linkId,
                    source_type: sourceType,
                    source_id: sourceId
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        // Remove the row from the table
                        $button.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            // Optionally, refresh table pagination/counts
                            // location.reload();
                        });
                    } else {
                        alert(response.data.message || 'Error deleting link.');
                        $button.text('Remove Link').prop('disabled', false).removeClass('button-disabled');
                    }
                },
                error: function() {
                    alert('AJAX error during deletion.');
                    $button.text('Remove Link').prop('disabled', false).removeClass('button-disabled');
                }
            });
        }
    });

    // ----- Mark as Fixed -----
    $('.wp-list-table').on('click', '.slhm-action-fixed', function(e) {
        e.preventDefault();
        var $button = $(this);
        var linkId = $button.data('link-id');

        if (confirm(slhm_ajax_object.confirm_mark_fixed)) {
            $button.text('Marking...').prop('disabled', true).addClass('button-disabled');
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'slhm_mark_fixed',
                    nonce: nonce,
                    link_id: linkId
                },
                success: function(response) {
                    if (response.success) {
                        alert(response.data.message);
                        // Remove the row from the table
                        $button.closest('tr').fadeOut(300, function() {
                            $(this).remove();
                            // Optionally, refresh table pagination/counts
                            // location.reload();
                        });
                    } else {
                        alert(response.data.message || 'Error marking link as fixed.');
                        $button.text('Mark as Fixed').prop('disabled', false).removeClass('button-disabled');
                    }
                },
                error: function() {
                    alert('AJAX error during marking as fixed.');
                    $button.text('Mark as Fixed').prop('disabled', false).removeClass('button-disabled');
                }
            });
        }
    });

    // ----- Export CSV Button URL -----
    // Ensure the export CSV link reflects current filters
    $('#slhm-link-filter-form').on('change', 'select', function() {
        updateExportCsvLink();
    });

    $('#slhm-link-filter-form').on('keyup', 'input[name="s"]', function() {
        // Debounce for search input to avoid too many updates
        clearTimeout($(this).data('timeout'));
        $(this).data('timeout', setTimeout(updateExportCsvLink, 500));
    });

    function updateExportCsvLink() {
        var baseUrl = ajaxurl + '?action=slhm_export_csv&nonce=' + nonce;
        var currentFilters = $('#slhm-link-filter-form').serialize(); // Get all form data
        var fullExportUrl = baseUrl + '&' + currentFilters;
        $('.slhm-export-csv-btn').attr('href', fullExportUrl);
    }

    // Initial update of the export link when the page loads
    updateExportCsvLink();
});