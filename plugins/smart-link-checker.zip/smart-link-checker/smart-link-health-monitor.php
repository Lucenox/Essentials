<?php
/**
 * Plugin Name: WP Smart Link Checker
 * Description: Memonitor status link keluar dan internal di postingan, halaman, dan komentar untuk mengidentifikasi link rusak atau redirect.
 * Version:     1.0.0
 * Author:      RivenSyx
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Pastikan tidak ada akses langsung ke file ini
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Definisikan konstanta untuk jalur dan URL plugin
if ( ! defined( 'SLHM_PATH' ) ) {
    define( 'SLHM_PATH', plugin_dir_path( __FILE__ ) );
}
if ( ! defined( 'SLHM_URL' ) ) {
    define( 'SLHM_URL', plugin_dir_url( __FILE__ ) );
}

/**
 * Fungsi ini akan dipanggil saat plugin diaktivasi.
 * Ini adalah tempat untuk menjalankan setup awal seperti membuat tabel database.
 */
function slhm_activate_plugin() {
    // Memuat hanya SLHM_DB untuk aktivasi tabel
    require_once SLHM_PATH . 'includes/class-slhm-db.php';
    $slhm_db = new SLHM_DB();
    $slhm_db->create_tables();

    // Jadwalkan pemindaian harian
    if ( ! wp_next_scheduled( 'slhm_daily_scan_event' ) ) {
        wp_schedule_event( time(), 'daily', 'slhm_daily_scan_event' );
    }
}
register_activation_hook( __FILE__, 'slhm_activate_plugin' );

/**
 * Fungsi ini akan dipanggil saat plugin dideaktivasi.
 * Ini adalah tempat untuk membersihkan apapun yang dibuat saat aktivasi (opsional).
 */
function slhm_deactivate_plugin() {
    // Hapus jadwal pemindaian saat plugin dinonaktifkan
    $timestamp = wp_next_scheduled( 'slhm_daily_scan_event' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'daily', 'slhm_daily_scan_event' );
    }
}
register_deactivation_hook( __FILE__, 'slhm_deactivate_plugin' );

/**
 * Memuat semua kelas yang dibutuhkan dan menjalankan plugin.
 */
function run_slhm() {
    // Memuat kelas-kelas inti dalam urutan yang benar
    // Pastikan tidak ada require_once ganda di dalam file kelas itu sendiri
    require_once SLHM_PATH . 'includes/class-slhm-db.php';
    require_once SLHM_PATH . 'includes/class-slhm-scanner.php';
    require_once SLHM_PATH . 'includes/class-slhm-ajax.php';
    require_once SLHM_PATH . 'includes/class-slhm-admin.php';
    require_once SLHM_PATH . 'includes/class-slhm-core.php';

    // Inisialisasi dependensi
    $slhm_db      = new SLHM_DB();
    $slhm_scanner = new SLHM_Scanner( $slhm_db );
    $slhm_ajax    = new SLHM_Ajax( $slhm_db, $slhm_scanner );
    $slhm_admin   = new SLHM_Admin( $slhm_db, $slhm_ajax ); // slhm_admin membutuhkan slhm_db dan slhm_ajax

    // Inisialisasi dan jalankan Core plugin
    $plugin = new SLHM_Core( $slhm_db, $slhm_scanner, $slhm_admin, $slhm_ajax );
    $plugin->run();
}

// Jalankan plugin setelah semua plugin lain dimuat
add_action( 'plugins_loaded', 'run_slhm' );