<div class="wrap">
    <h1><?php esc_html_e( 'WP Smart Link Checker', 'slhm' ); ?></h1>

    <div class="slhm-header-actions">
        <button id="slhm-start-scan-btn" class="button button-primary"><?php esc_html_e( 'Start Scan Now', 'slhm' ); ?></button>
        <span id="slhm-scan-message" class="slhm-message"></span>
    </div>

    <form id="slhm-link-filter-form" method="get">
        <input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>" />
        <?php
        // Render the list table
        $list_table->display();
        ?>
    </form>
</div>

<div id="slhm-edit-modal" class="slhm-modal" style="display:none;">
    <div class="slhm-modal-content">
        <span class="slhm-close-button">&times;</span>
        <h2><?php esc_html_e( 'Edit Link URL', 'slhm' ); ?></h2>
        <form id="slhm-edit-form">
            <input type="hidden" id="slhm_link_id" name="link_id">
            <input type="hidden" id="slhm_source_type" name="source_type">
            <input type="hidden" id="slhm_source_id" name="source_id">

            <p>
                <label for="slhm_old_url"><?php esc_html_e( 'Original URL:', 'slhm' ); ?></label>
                <input type="text" id="slhm_old_url" name="old_url" readonly>
            </p>
            <p>
                <label for="slhm_new_url"><?php esc_html_e( 'New URL:', 'slhm' ); ?></label>
                <input type="url" id="slhm_new_url" name="new_url" required>
            </p>
            <button type="submit" class="button button-primary"><?php esc_html_e( 'Update Link', 'slhm' ); ?></button>
            <span id="slhm-edit-message" class="slhm-message"></span>
        </form>
    </div>
</div>