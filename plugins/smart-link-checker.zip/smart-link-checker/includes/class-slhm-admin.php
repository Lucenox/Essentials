<?php
// Pastikan tidak diakses langsung
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// PENTING: Jangan ada require_once untuk SLHM_DB atau SLHM_Ajax di sini!
// Kelas ini menerima instance SLHM_DB dan SLHM_Ajax melalui konstruktornya.

class SLHM_Admin {

    private $slhm_db;
    private $slhm_ajax;

    public function __construct( $slhm_db, $slhm_ajax ) {
        $this->slhm_db   = $slhm_db;
        $this->slhm_ajax = $slhm_ajax; // Inisialisasi
    }

    /**
     * Menambahkan menu di Dashboard WordPress.
     */
    public function add_admin_menu() {
        add_menu_page(
            __( 'Link Health', 'slhm' ),    // Page title
            __( 'Link Health', 'slhm' ),    // Menu title
            'manage_options',                 // Capability required to access
            'slhm-dashboard',                 // Menu slug
            array( $this, 'display_admin_page' ), // Callback function to render the page
            'dashicons-external',             // Icon URL/class
            60                                // Position
        );
    }

    /**
     * Menampilkan halaman admin plugin.
     */
    public function display_admin_page() {
        // Memuat List Table Class WordPress
        if ( ! class_exists( 'WP_List_Table' ) ) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
        }

        // Memuat custom List Table kita
        require_once SLHM_PATH . 'includes/class-slhm-list-table.php';
        $list_table = new SLHM_List_Table( $this->slhm_db );
        $list_table->prepare_items();

        // Include template halaman admin
        include_once SLHM_PATH . 'templates/admin-page.php';
    }

    /**
     * Mendaftarkan dan mengantrekan skrip dan gaya admin.
     */
    public function enqueue_admin_assets() {
        wp_enqueue_style( 'slhm-admin-css', SLHM_URL . 'assets/css/slhm-admin.css', array(), '1.0.0' );
        wp_enqueue_script( 'slhm-admin-js', SLHM_URL . 'assets/js/slhm-admin.js', array( 'jquery' ), '1.0.0', true );

        // Meneruskan data ke skrip JavaScript
        wp_localize_script( 'slhm-admin-js', 'slhm_ajax_object', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'slhm_admin_nonce' ),
            'confirm_update' => __( 'Are you sure you want to update this link?', 'slhm' ),
            'confirm_delete' => __( 'Are you sure you want to delete this link from content? This action is irreversible.', 'slhm' ),
            'confirm_mark_fixed' => __( 'Are you sure you want to mark this link as fixed? It will be removed from the list.', 'slhm' ),
            'scan_initiated' => __( 'Scan initiated successfully! Please refresh the page after a moment to see updated results.', 'slhm' ),
            'scan_failed' => __( 'Failed to initiate scan.', 'slhm' ),
        ) );
    }

}