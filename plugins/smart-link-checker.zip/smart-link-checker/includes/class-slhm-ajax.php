<?php
// Pastikan tidak diakses langsung
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// PENTING: Jangan ada require_once untuk SLHM_DB atau SLHM_Scanner di sini!
// Kelas ini menerima instance SLHM_DB dan SLHM_Scanner melalui konstruktornya.

class SLHM_Ajax {

    private $slhm_db;
    private $slhm_scanner;

    public function __construct( $slhm_db, $slhm_scanner ) {
        $this->slhm_db      = $slhm_db;
        $this->slhm_scanner = $slhm_scanner;
    }

    public function init_hooks() {
        add_action( 'wp_ajax_slhm_update_link', array( $this, 'ajax_update_link' ) );
        add_action( 'wp_ajax_slhm_delete_link', array( $this, 'ajax_delete_link' ) );
        add_action( 'wp_ajax_slhm_mark_fixed', array( $this, 'ajax_mark_fixed' ) );
        add_action( 'wp_ajax_slhm_start_manual_scan', array( $this, 'ajax_start_manual_scan' ) );
        // Tambahkan hook untuk ekspor CSV
        add_action( 'wp_ajax_slhm_export_csv', array( $this, 'ajax_export_csv' ) );
        // Tambahkan hook untuk progress bar jika ingin pemindaian real-time
        // add_action( 'wp_ajax_slhm_get_scan_progress', array( $this, 'ajax_get_scan_progress' ) );
    }

    /**
     * AJAX untuk memperbarui URL link di konten.
     */
    public function ajax_update_link() {
        check_ajax_referer( 'slhm_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) { // Atau 'manage_options'
            wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'slhm' ) ) );
        }

        $link_id      = isset( $_POST['link_id'] ) ? intval( $_POST['link_id'] ) : 0;
        $new_url      = isset( $_POST['new_url'] ) ? esc_url_raw( $_POST['new_url'] ) : ''; // Sanitasi URL
        $target_type  = isset( $_POST['source_type'] ) ? sanitize_text_field( $_POST['source_type'] ) : ''; // 'post', 'comment', etc.
        $target_id    = isset( $_POST['source_id'] ) ? intval( $_POST['source_id'] ) : 0;

        if ( ! $link_id || empty( $new_url ) || ! $target_id || empty( $target_type ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid data provided.', 'slhm' ) ) );
        }

        $link_data = $this->slhm_db->get_link_by_id( $link_id );
        if ( ! $link_data ) {
            wp_send_json_error( array( 'message' => __( 'Link not found in database.', 'slhm' ) ) );
        }

        $old_url = $link_data->link_url;

        // Perbarui konten post/komentar
        $content_updated = false;
        if ( 'comment' === $target_type ) {
            $comment = get_comment( $target_id );
            if ( $comment ) {
                $new_content = str_replace( $old_url, $new_url, $comment->comment_content );
                $update_result = wp_update_comment( array(
                    'comment_ID'      => $target_id,
                    'comment_content' => $new_content,
                ) );
                if ( $update_result ) {
                    $content_updated = true;
                }
            }
        } else { // Asumsi Post Type
            $post = get_post( $target_id );
            if ( $post ) {
                $new_content = str_replace( $old_url, $new_url, $post->post_content );
                $update_result = wp_update_post( array(
                    'ID'           => $target_id,
                    'post_content' => $new_content,
                ) );
                if ( $update_result ) {
                    $content_updated = true;
                }
            }
        }

        if ( $content_updated ) {
            // Perbarui status di database setelah perubahan konten dan scan ulang link itu
            // Panggil method check_link_status dari instance slhm_scanner
            $check_result = $this->slhm_scanner->check_link_status( $new_url );
            $new_status_code = $check_result['status_code'];
            $is_broken_flag  = ( $new_status_code === 0 || $new_status_code >= 400 ) ? 1 : 0;
            $is_redirect_flag = ( $new_status_code >= 300 && $new_status_code < 400 ) ? 1 : 0;
            $redirect_to_url  = isset( $check_result['redirect_to'] ) ? $check_result['redirect_to'] : null;

            $this->slhm_db->update_link_status( $link_id, $new_status_code, $is_broken_flag, $is_redirect_flag, $redirect_to_url );

            wp_send_json_success( array(
                'message'      => __( 'Link updated successfully!', 'slhm' ),
                'new_status'   => $new_status_code,
                'is_broken'    => $is_broken_flag,
                'is_redirect'  => $is_redirect_flag,
                'redirect_to'  => $redirect_to_url,
                'link_id'      => $link_id,
            ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to update link in content.', 'slhm' ) ) );
        }
    }

    /**
     * AJAX untuk menghapus link dari konten.
     */
    public function ajax_delete_link() {
        check_ajax_referer( 'slhm_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'slhm' ) ) );
        }

        $link_id      = isset( $_POST['link_id'] ) ? intval( $_POST['link_id'] ) : 0;
        $target_type  = isset( $_POST['source_type'] ) ? sanitize_text_field( $_POST['source_type'] ) : '';
        $target_id    = isset( $_POST['source_id'] ) ? intval( $_POST['source_id'] ) : 0;

        if ( ! $link_id || ! $target_id || empty( $target_type ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid data provided.', 'slhm' ) ) );
        }

        $link_data = $this->slhm_db->get_link_by_id( $link_id );
        if ( ! $link_data ) {
            wp_send_json_error( array( 'message' => __( 'Link not found in database.', 'slhm' ) ) );
        }

        $old_url = $link_data->link_url;
        $anchor_text = $link_data->anchor_text; // Dapatkan teks jangkar

        $content_updated = false;
        if ( 'comment' === $target_type ) {
            $comment = get_comment( $target_id );
            if ( $comment ) {
                // Hapus tag <a>, sisakan teks jangkar
                // Menggunakan preg_replace untuk penanganan yang lebih baik jika ada atribut lain di tag <a>
                $new_content = preg_replace( '#<a[^>]*href="' . preg_quote( $old_url, '#' ) . '"[^>]*>(.*?)</a>#i', '$1', $comment->comment_content );
                $update_result = wp_update_comment( array(
                    'comment_ID'      => $target_id,
                    'comment_content' => $new_content,
                ) );
                if ( $update_result ) {
                    $content_updated = true;
                }
            }
        } else { // Asumsi Post Type
            $post = get_post( $target_id );
            if ( $post ) {
                // Hapus tag <a>, sisakan teks jangkar
                $new_content = preg_replace( '#<a[^>]*href="' . preg_quote( $old_url, '#' ) . '"[^>]*>(.*?)</a>#i', '$1', $post->post_content );
                $update_result = wp_update_post( array(
                    'ID'           => $target_id,
                    'post_content' => $new_content,
                ) );
                if ( $update_result ) {
                    $content_updated = true;
                }
            }
        }

        if ( $content_updated ) {
            $this->slhm_db->delete_link( $link_id ); // Hapus dari database plugin
            wp_send_json_success( array( 'message' => __( 'Link removed successfully!', 'slhm' ), 'link_id' => $link_id ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to remove link from content.', 'slhm' ) ) );
        }
    }

    /**
     * AJAX untuk menandai link sebagai sudah diperbaiki (menghapus dari daftar error).
     */
    public function ajax_mark_fixed() {
        check_ajax_referer( 'slhm_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'slhm' ) ) );
        }

        $link_id = isset( $_POST['link_id'] ) ? intval( $_POST['link_id'] ) : 0;
        if ( ! $link_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid link ID.', 'slhm' ) ) );
        }

        // Cukup perbarui status di database plugin
        $result = $this->slhm_db->update_link_status( $link_id, 200, 0, 0, null ); // Anggap 200 OK, tidak broken, tidak redirect
        if ( $result !== false ) {
            wp_send_json_success( array( 'message' => __( 'Link marked as fixed!', 'slhm' ), 'link_id' => $link_id ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'Failed to mark link as fixed.', 'slhm' ) ) );
        }
    }

    /**
     * AJAX untuk memulai pemindaian manual.
     */
    public function ajax_start_manual_scan() {
        check_ajax_referer( 'slhm_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to do this.', 'slhm' ) ) );
        }

        // Memicu event cron secara langsung untuk pemindaian instan
        // Note: Untuk situs besar, ini bisa menyebabkan timeout.
        // Solusi lebih lanjut adalah dengan memicu proses background yang terpisah
        // atau menggunakan Action Scheduler.
        do_action( 'slhm_daily_scan_event' ); // Memanggil fungsi pemindaian

        wp_send_json_success( array( 'message' => __( 'Scan initiated successfully! Please refresh the page after a moment to see updated results.', 'slhm' ) ) );
    }

    /**
     * AJAX untuk mengekspor data link ke CSV.
     */
    public function ajax_export_csv() {
        // Lakukan pengecekan keamanan
        check_ajax_referer( 'slhm_admin_nonce', 'nonce' );

        // Pastikan user memiliki kapabilitas yang cukup
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have permission to do this.', 'slhm' ) );
        }

        // Ambil parameter filter saat ini dari request GET
        // Ini penting agar ekspor CSV sesuai dengan filter yang sedang diterapkan di halaman admin
        $filter_args = array(
            'is_broken'   => isset( $_GET['is_broken'] ) ? intval( $_GET['is_broken'] ) : null,
            'is_redirect' => isset( $_GET['is_redirect'] ) ? intval( $_GET['is_redirect'] ) : null,
            'source_type' => isset( $_GET['source_type'] ) ? sanitize_text_field( $_GET['source_type'] ) : 'all',
            's'           => isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '',
            'per_page'    => -1, // Ambil SEMUA data, tidak ada paginasi untuk ekspor
        );

        // Panggil method dari SLHM_DB untuk mendapatkan data link sesuai filter
        $links_to_export = $this->slhm_db->get_links( $filter_args );

        // Tentukan nama file CSV
        $filename = 'slhm-broken-links-' . date( 'Ymd_His' ) . '.csv';

        // Set header HTTP untuk memberitahu browser bahwa ini adalah file CSV untuk diunduh
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=' . $filename );

        // Buka "output stream" ke browser
        $output = fopen( 'php://output', 'w' );

        // Tulis baris header CSV
        fputcsv( $output, array(
            'Link ID',
            'Source ID',
            'Source Type',
            'Source Title',
            'Link URL',
            'Anchor Text',
            'HTTP Status',
            'Is Broken',
            'Is Redirect',
            'Redirect To',
            'Last Checked'
        ) );

        // Tulis data setiap link ke file CSV
        foreach ( $links_to_export as $link ) {
            $source_title = '';
            // Tentukan judul sumber berdasarkan tipe (post, page, comment, CPT)
            if ( 'comment' === $link->source_type ) {
                $comment = get_comment( $link->source_id );
                $source_title = $comment ? 'Comment ID: ' . $link->source_id : 'Comment Deleted';
            } else {
                $post = get_post( $link->source_id );
                // Pastikan post_type_object ada dan punya labels
                $post_type_label = '';
                $post_type_obj = $post ? get_post_type_object( $post->post_type ) : null;
                if ( $post_type_obj && isset( $post_type_obj->labels->singular_name ) ) {
                    $post_type_label = $post_type_obj->labels->singular_name;
                }
                $source_title = $post ? $post->post_title . ' (' . $post_type_label . ')' : 'Post Deleted';
            }

            fputcsv( $output, array(
                $link->id,
                $link->source_id,
                $link->source_type,
                $source_title,
                $link->link_url,
                $link->anchor_text,
                $link->http_status,
                $link->is_broken ? 'Yes' : 'No', // Konversi boolean ke 'Yes'/'No'
                $link->is_redirect ? 'Yes' : 'No', // Konversi boolean ke 'Yes'/'No'
                $link->redirect_to,
                $link->last_checked
            ) );
        }

        // Tutup output stream
        fclose( $output );
        exit; // Penting: Hentikan eksekusi script setelah CSV dikirim
    }

    // /**
    //  * AJAX untuk mendapatkan progres pemindaian (membutuhkan lebih banyak state tracking di scanner)
    //  */
    // public function ajax_get_scan_progress() {
    //     check_ajax_referer( 'slhm_admin_nonce', 'nonce' );

    //     $progress = get_option( 'slhm_scan_progress', array( 'current' => 0, 'total' => 0, 'status' => 'idle' ) );
    //     wp_send_json_success( $progress );
    // }
}