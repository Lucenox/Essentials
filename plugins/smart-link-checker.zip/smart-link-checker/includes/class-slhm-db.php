<?php
// Pastikan tidak diakses langsung
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class SLHM_DB {

    private $wpdb;
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->wpdb       = $wpdb;
        $this->table_name = $this->wpdb->prefix . 'slhm_links';
    }

    /**
     * Membuat tabel database saat plugin diaktivasi.
     */
    public function create_tables() {
        $charset_collate = $this->wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$this->table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_id bigint(20) unsigned NOT NULL,
            source_type varchar(50) NOT NULL,
            link_url text NOT NULL,
            anchor_text text NULL,
            http_status smallint(3) DEFAULT NULL,
            is_broken tinyint(1) DEFAULT 0 NOT NULL,
            is_redirect tinyint(1) DEFAULT 0 NOT NULL,
            redirect_to text NULL,
            last_checked datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
            PRIMARY KEY (id),
            KEY source_idx (source_id, source_type)
        ) {$charset_collate};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    /**
     * Menambahkan link baru ke database.
     *
     * @param int    $source_id ID post/comment.
     * @param string $source_type Tipe sumber ('post', 'page', 'comment', CPT slug).
     * @param string $link_url URL link.
     * @param string $anchor_text Teks jangkar.
     * @return int|false ID baris yang disisipkan atau false jika gagal.
     */
    public function add_link( $source_id, $source_type, $link_url, $anchor_text ) {
        // Cek apakah link sudah ada untuk source_id dan source_type yang sama
        $existing_link = $this->wpdb->get_row(
            $this->wpdb->prepare(
                "SELECT id FROM {$this->table_name} WHERE source_id = %d AND source_type = %s AND link_url = %s",
                $source_id,
                $source_type,
                $link_url
            )
        );

        if ( $existing_link ) {
            return $existing_link->id; // Link sudah ada, kembalikan ID-nya
        }

        return $this->wpdb->insert(
            $this->table_name,
            array(
                'source_id'   => $source_id,
                'source_type' => $source_type,
                'link_url'    => $link_url,
                'anchor_text' => $anchor_text,
                'last_checked' => current_time( 'mysql' ), // Set initial check time
            ),
            array( '%d', '%s', '%s', '%s', '%s' )
        );
    }

    /**
     * Memperbarui status link.
     *
     * @param int    $link_id ID link.
     * @param int    $http_status Kode status HTTP.
     * @param int    $is_broken 1 jika rusak, 0 jika tidak.
     * @param int    $is_redirect 1 jika redirect, 0 jika tidak.
     * @param string $redirect_to URL redirect tujuan (nullable).
     * @return int|false Jumlah baris yang terpengaruh atau false jika gagal.
     */
    public function update_link_status( $link_id, $http_status, $is_broken, $is_redirect, $redirect_to = null ) {
        return $this->wpdb->update(
            $this->table_name,
            array(
                'http_status'  => $http_status,
                'is_broken'    => $is_broken,
                'is_redirect'  => $is_redirect,
                'redirect_to'  => $redirect_to,
                'last_checked' => current_time( 'mysql' ),
            ),
            array( 'id' => $link_id ),
            array( '%d', '%d', '%d', '%s', '%s' ),
            array( '%d' )
        );
    }

    /**
     * Menghapus link dari database.
     *
     * @param int $link_id ID link yang akan dihapus.
     * @return int|false Jumlah baris yang dihapus atau false jika gagal.
     */
    public function delete_link( $link_id ) {
        return $this->wpdb->delete( $this->table_name, array( 'id' => $link_id ), array( '%d' ) );
    }

    /**
     * Mengambil satu link berdasarkan ID.
     *
     * @param int $link_id ID link.
     * @return object|null Objek link atau null jika tidak ditemukan.
     */
    public function get_link_by_id( $link_id ) {
        return $this->wpdb->get_row(
            $this->wpdb->prepare( "SELECT * FROM {$this->table_name} WHERE id = %d", $link_id )
        );
    }

    /**
     * Mengambil semua link untuk proses pemindaian.
     *
     * @return array Array objek link.
     */
    public function get_all_links_for_scan() {
        return $this->wpdb->get_results( "SELECT id, link_url FROM {$this->table_name}" );
    }

    /**
     * Mengambil link berdasarkan filter dan paginasi.
     *
     * @param array $args Argumen filter dan paginasi.
     * @return array Array objek link.
     */
    public function get_links( $args = array() ) {
        $defaults = array(
            'per_page'    => 20,
            'offset'      => 0,
            'is_broken'   => null,    // 1=broken, 0=not broken, null=all
            'is_redirect' => null,    // 1=redirect, 0=not redirect, null=all
            'source_type' => 'all',   // 'post', 'comment', 'all'
            's'           => '',      // Search term for link_url or anchor_text
            'orderby'     => 'id',
            'order'       => 'DESC',
        );
        $args = wp_parse_args( $args, $defaults );

        $where_clauses = array();
        $query_params = array();
        $query_types = array(); // Untuk menyimpan jenis placeholder

        if ( $args['is_broken'] !== null ) {
            $where_clauses[] = 'is_broken = %d';
            $query_params[] = $args['is_broken'];
            $query_types[] = '%d';
        }

        if ( $args['is_redirect'] !== null ) {
            $where_clauses[] = 'is_redirect = %d';
            $query_params[] = $args['is_redirect'];
            $query_types[] = '%d';
        }

        if ( $args['source_type'] !== 'all' && ! empty( $args['source_type'] ) ) {
            $where_clauses[] = 'source_type = %s';
            $query_params[] = $args['source_type'];
            $query_types[] = '%s';
        }

        if ( ! empty( $args['s'] ) ) {
            $search_term = '%' . $this->wpdb->esc_like( $args['s'] ) . '%';
            $where_clauses[] = '(link_url LIKE %s OR anchor_text LIKE %s)';
            $query_params[] = $search_term;
            $query_params[] = $search_term;
            $query_types[] = '%s';
            $query_types[] = '%s';
        }

        $where_sql = '';
        if ( ! empty( $where_clauses ) ) {
            $where_sql = 'WHERE ' . implode( ' AND ', $where_clauses );
        }

        // Sanitasi orderby dan order
        $orderby = sanitize_sql_orderby( $args['orderby'] );
        $order   = in_array( strtoupper( $args['order'] ), array( 'ASC', 'DESC' ) ) ? strtoupper( $args['order'] ) : 'DESC';


        $limit_sql = '';
        if ( $args['per_page'] > 0 ) {
            $limit_sql = 'LIMIT %d OFFSET %d';
            $query_params[] = $args['per_page'];
            $query_params[] = $args['offset'];
            $query_types[] = '%d';
            $query_types[] = '%d';
        }

        $query = "SELECT * FROM {$this->table_name} {$where_sql} ORDER BY {$orderby} {$order} {$limit_sql}";

        // Gunakan prepare hanya jika ada parameter yang akan diprepare
        if ( ! empty( $query_params ) ) {
            // Gunakan sprintf untuk membangun query dengan placeholder yang benar
            $prepared_query_format = vsprintf( str_replace( '%', '%%', $query ), array_values( $query_types ) );
            return $this->wpdb->get_results( $this->wpdb->prepare( $prepared_query_format, ...$query_params ) );
        } else {
            return $this->wpdb->get_results( $query );
        }
    }

    /**
     * Menghitung total jumlah link berdasarkan filter.
     *
     * @param array $args Argumen filter.
     * @return int Jumlah total link.
     */
    public function count_links( $args = array() ) {
        $defaults = array(
            'is_broken'   => null,
            'is_redirect' => null,
            'source_type' => 'all',
            's'           => '',
        );
        $args = wp_parse_args( $args, $defaults );

        $where_clauses = array();
        $query_params = array();
        $query_types = array();

        if ( $args['is_broken'] !== null ) {
            $where_clauses[] = 'is_broken = %d';
            $query_params[] = $args['is_broken'];
            $query_types[] = '%d';
        }

        if ( $args['is_redirect'] !== null ) {
            $where_clauses[] = 'is_redirect = %d';
            $query_params[] = $args['is_redirect'];
            $query_types[] = '%d';
        }

        if ( $args['source_type'] !== 'all' && ! empty( $args['source_type'] ) ) {
            $where_clauses[] = 'source_type = %s';
            $query_params[] = $args['source_type'];
            $query_types[] = '%s';
        }

        if ( ! empty( $args['s'] ) ) {
            $search_term = '%' . $this->wpdb->esc_like( $args['s'] ) . '%';
            $where_clauses[] = '(link_url LIKE %s OR anchor_text LIKE %s)';
            $query_params[] = $search_term;
            $query_params[] = $search_term;
            $query_types[] = '%s';
            $query_types[] = '%s';
        }

        $where_sql = '';
        if ( ! empty( $where_clauses ) ) {
            $where_sql = 'WHERE ' . implode( ' AND ', $where_clauses );
        }

        $query = "SELECT COUNT(id) FROM {$this->table_name} {$where_sql}";

        // Gunakan prepare hanya jika ada parameter yang akan diprepare
        if ( ! empty( $query_params ) ) {
            $prepared_query_format = vsprintf( str_replace( '%', '%%', $query ), array_values( $query_types ) );
            return (int) $this->wpdb->get_var( $this->wpdb->prepare( $prepared_query_format, ...$query_params ) );
        } else {
            return (int) $this->wpdb->get_var( $query );
        }
    }

    /**
     * Mengosongkan tabel link. Digunakan sebelum pemindaian baru.
     */
    public function truncate_links_table() {
        $this->wpdb->query( "TRUNCATE TABLE {$this->table_name}" );
    }

}