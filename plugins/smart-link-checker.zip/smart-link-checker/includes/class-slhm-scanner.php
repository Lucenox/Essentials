<?php
// Pastikan tidak diakses langsung
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// PENTING: Jangan ada require_once SLHM_DB di sini, karena sudah dimuat di file utama!
// require_once SLHM_PATH . 'includes/class-slhm-db.php'; // <--- BARIS INI TIDAK BOLEH ADA DI SINI

class SLHM_Scanner {

    private $slhm_db;

    public function __construct( $slhm_db ) {
        $this->slhm_db = $slhm_db;
    }

    /**
     * Memindai semua konten di post, page, dan komentar untuk mencari link.
     */
    public function scan_all_content() {
        // Hapus semua link yang ada di DB sebelum memulai scan baru
        $this->slhm_db->truncate_links_table();

        // 1. Scan Posts dan Pages
        $post_types = get_post_types( array( 'public' => true ), 'names' );
        unset( $post_types['attachment'] ); // Jangan scan attachment

        $args = array(
            'post_type'      => $post_types,
            'post_status'    => 'publish',
            'posts_per_page' => -1, // Ambil semua post
            'no_found_rows'  => true,
            'fields'         => 'ids', // Hanya ambil ID untuk efisiensi
        );
        $posts_query = new WP_Query( $args );

        if ( $posts_query->have_posts() ) {
            foreach ( $posts_query->posts as $post_id ) {
                $post = get_post( $post_id );
                if ( $post && ! empty( $post->post_content ) ) {
                    $this->find_and_store_links( $post->post_content, $post_id, $post->post_type );
                }
            }
        }

        // 2. Scan Komentar
        $comments = get_comments( array(
            'status'  => 'approve',
            'type'    => 'comment',
            'number'  => -1, // Ambil semua komentar
        ) );

        foreach ( $comments as $comment ) {
            if ( ! empty( $comment->comment_content ) ) {
                $this->find_and_store_links( $comment->comment_content, $comment->comment_ID, 'comment' );
            }
        }

        // Setelah semua link ditemukan, scan status HTTP mereka
        $this->scan_all_stored_links();
    }

    /**
     * Mencari link dalam konten dan menyimpannya ke database.
     *
     * @param string $content Konten (post_content atau comment_content).
     * @param int    $source_id ID sumber (post ID atau comment ID).
     * @param string $source_type Tipe sumber ('post', 'page', 'comment', CPT slug).
     */
    private function find_and_store_links( $content, $source_id, $source_type ) {
        // Regex untuk menemukan tag <a> dan mendapatkan href serta teks jangkar
        preg_match_all( '/<a\s+(?:[^>]*?\s+)?href=[\'"]([^\'"]+)[\'"][^>]*>(.*?)<\/a>/i', $content, $matches, PREG_SET_ORDER );

        if ( ! empty( $matches ) ) {
            foreach ( $matches as $match ) {
                $link_url    = esc_url_raw( $match[1] ); // URL
                $anchor_text = sanitize_text_field( strip_tags( $match[2] ) ); // Teks jangkar tanpa HTML

                // Hanya simpan link yang valid dan tidak kosong
                if ( ! empty( $link_url ) ) {
                    $this->slhm_db->add_link(
                        $source_id,
                        $source_type,
                        $link_url,
                        $anchor_text
                    );
                }
            }
        }
    }

    /**
     * Memindai status HTTP dari semua link yang ada di database.
     */
    private function scan_all_stored_links() {
        $links = $this->slhm_db->get_all_links_for_scan(); // Method baru untuk efisiensi

        foreach ( $links as $link ) {
            $check_result = $this->check_link_status( $link->link_url );
            $http_status_code = $check_result['status_code'];
            $is_broken        = ( $http_status_code === 0 || $http_status_code >= 400 ) ? 1 : 0;
            $is_redirect      = ( $http_status_code >= 300 && $http_status_code < 400 ) ? 1 : 0;
            $redirect_to      = isset( $check_result['redirect_to'] ) ? $check_result['redirect_to'] : null;

            $this->slhm_db->update_link_status(
                $link->id,
                $http_status_code,
                $is_broken,
                $is_redirect,
                $redirect_to
            );
        }
    }

    /**
     * Mengecek status HTTP dari sebuah URL.
     *
     * @param string $url URL yang akan dicek.
     * @return array Array berisi status_code dan redirect_to (jika ada).
     */
    public function check_link_status( $url ) {
        $status_code = 0; // Default untuk unknown/error
        $redirect_to = null;

        // Skip internal URLs untuk menghemat resource, anggap OK
        if ( strpos( $url, home_url() ) === 0 ) {
             // Jika ini adalah link internal, anggap status 200 OK.
             // Kita bisa menambahkan logika lebih kompleks di sini
             // jika ingin mengecek internal link yang benar-benar rusak (misal: 404 pada permalink)
             // tetapi itu akan jauh lebih memakan waktu dan resource.
             return array(
                 'status_code' => 200,
                 'redirect_to' => null,
             );
        }

        // Lakukan permintaan HTTP menggunakan WordPress HTTP API
        $response = wp_remote_head( $url, array(
            'timeout'     => 10, // Timeout 10 detik
            'redirection' => 5,  // Ikuti hingga 5 redirect
            'blocking'    => true, // Jangan asinkron
            'sslverify'   => false, // Bisa diatur true jika sertifikat SSL selalu valid
        ) );

        if ( is_wp_error( $response ) ) {
            // Ada error saat melakukan request (misalnya, domain tidak ditemukan, timeout)
            $status_code = 0; // Menandakan error
        } else {
            $status_code = wp_remote_retrieve_response_code( $response );
            // Cek jika ada redirect
            if ( $status_code >= 300 && $status_code < 400 ) {
                $redirect_to = wp_remote_retrieve_header( $response, 'location' );
                // Pastikan redirect_to adalah URL yang valid
                if ( ! filter_var( $redirect_to, FILTER_VALIDATE_URL ) ) {
                    $redirect_to = null;
                }
            }
        }

        // Jika status 405 (Method Not Allowed) tapi link valid, coba dengan GET
        // Beberapa server mungkin tidak mengizinkan HEAD request
        if ( $status_code === 405 || ( $status_code === 0 && ! is_wp_error( $response ) ) ) {
            $response = wp_remote_get( $url, array(
                'timeout'     => 10,
                'redirection' => 5,
                'blocking'    => true,
                'sslverify'   => false,
            ) );

            if ( ! is_wp_error( $response ) ) {
                $status_code = wp_remote_retrieve_response_code( $response );
                if ( $status_code >= 300 && $status_code < 400 ) {
                    $redirect_to = wp_remote_retrieve_header( $response, 'location' );
                    if ( ! filter_var( $redirect_to, FILTER_VALIDATE_URL ) ) {
                        $redirect_to = null;
                    }
                }
            }
        }

        return array(
            'status_code' => $status_code,
            'redirect_to' => $redirect_to,
        );
    }
}