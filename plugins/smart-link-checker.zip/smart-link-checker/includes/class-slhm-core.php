<?php
// Pastikan tidak diakses langsung
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// PENTING: Jangan ada require_once untuk kelas lain di sini.
// Kelas ini menerima semua dependensinya melalui konstruktor.

class SLHM_Core {

    private $slhm_db;
    private $slhm_scanner;
    private $slhm_admin;
    private $slhm_ajax;

    public function __construct( $slhm_db, $slhm_scanner, $slhm_admin, $slhm_ajax ) {
        $this->slhm_db      = $slhm_db;
        $this->slhm_scanner = $slhm_scanner;
        $this->slhm_admin   = $slhm_admin;
        $this->slhm_ajax    = $slhm_ajax;
    }

    public function run() {
        // Hook untuk proses pemindaian otomatis (cron job)
        add_action( 'slhm_daily_scan_event', array( $this->slhm_scanner, 'scan_all_content' ) );

        // Hooks untuk admin area (menu dan enqueue scripts)
        add_action( 'admin_menu', array( $this->slhm_admin, 'add_admin_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this->slhm_admin, 'enqueue_admin_assets' ) );

        // Inisialisasi hooks untuk AJAX
        $this->slhm_ajax->init_hooks();
    }

}