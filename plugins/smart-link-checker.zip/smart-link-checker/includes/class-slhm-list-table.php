<?php
// Pastikan tidak diakses langsung
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// WP_List_Table sudah di-require di class-slhm-admin.php sebelum ini digunakan

class SLHM_List_Table extends WP_List_Table {

    private $slhm_db;

    public function __construct( $slhm_db ) {
        parent::__construct( array(
            'singular' => 'link',
            'plural'   => 'links',
            'ajax'     => true,
        ) );
        $this->slhm_db = $slhm_db;
    }

    /**
     * Get a list of columns.
     *
     * @return array
     */
    public function get_columns() {
        $columns = array(
            'cb'            => '<input type="checkbox" />', // Kolom untuk bulk actions
            'link_url'      => __( 'Link URL', 'slhm' ),
            'anchor_text'   => __( 'Anchor Text', 'slhm' ),
            'source_type'   => __( 'Source Type', 'slhm' ),
            'source_title'  => __( 'Source', 'slhm' ),
            'http_status'   => __( 'Status', 'slhm' ),
            'last_checked'  => __( 'Last Checked', 'slhm' ),
            'actions'       => __( 'Actions', 'slhm' ), // Kolom untuk tombol aksi
        );
        return $columns;
    }

    /**
     * Handle the 'cb' column (checkbox).
     *
     * @param object $item
     * @return string
     */
    public function column_cb( $item ) {
        return sprintf(
            '<input type="checkbox" name="%1$s[]" value="%2$s" />',
            $this->_args['singular'],
            $item->id
        );
    }

    /**
     * Default column renderer.
     *
     * @param object $item
     * @param string $column_name
     * @return string
     */
    public function column_default( $item, $column_name ) {
        switch ( $column_name ) {
            case 'source_title':
                $source_title = '';
                $edit_link = '';

                if ( 'comment' === $item->source_type ) {
                    $comment = get_comment( $item->source_id );
                    if ( $comment ) {
                        $source_title = 'Comment ID: ' . $item->source_id;
                        $edit_link = get_edit_comment_link( $item->source_id );
                    } else {
                        $source_title = 'Comment Deleted';
                    }
                } else {
                    $post = get_post( $item->source_id );
                    if ( $post ) {
                        // Dapatkan nama tunggal post type, misal: 'Post', 'Page'
                        $post_type_label = '';
                        $post_type_obj = get_post_type_object( $post->post_type );
                        if ($post_type_obj && isset($post_type_obj->labels->singular_name)) {
                            $post_type_label = $post_type_obj->labels->singular_name;
                        }
                        $source_title = $post->post_title . ' (' . $post_type_label . ')';
                        $edit_link = get_edit_post_link( $item->source_id );
                    } else {
                        $source_title = 'Post Deleted';
                    }
                }

                if ( ! empty( $edit_link ) ) {
                    return sprintf( '<a href="%s" target="_blank">%s</a>', esc_url( $edit_link ), esc_html( $source_title ) );
                } else {
                    return esc_html( $source_title );

                }

            case 'link_url':
                $output = sprintf( '<div class="slhm-link-url-wrapper"><a href="%s" target="_blank" class="slhm-external-link">%s</a>', esc_url( $item->link_url ), esc_html( $item->link_url ) );
                if ( $item->is_redirect && ! empty( $item->redirect_to ) ) {
                    $output .= '<br><small class="slhm-redirect-info">' . __( 'Redirects to:', 'slhm' ) . ' <a href="' . esc_url( $item->redirect_to ) . '" target="_blank">' . esc_html( $item->redirect_to ) . '</a></small>';
                }
                $output .= '</div>';
                return $output;

            case 'http_status':
                $class = 'slhm-status-ok';
                $status_text = $item->http_status;
                if ( $item->is_broken ) {
                    $class = 'slhm-status-broken';
                    $status_text = $item->http_status . ' ' . __( '(Broken)', 'slhm' );
                } elseif ( $item->is_redirect ) {
                    $class = 'slhm-status-redirect';
                    $status_text = $item->http_status . ' ' . __( '(Redirect)', 'slhm' );
                } elseif ( $item->http_status === 0 ) {
                    $class = 'slhm-status-error';
                    $status_text = __( 'Unknown (Error)', 'slhm' );
                }
                return sprintf( '<span class="%s">%s</span>', esc_attr( $class ), esc_html( $status_text ) );

            case 'actions':
                $actions = array();
                $actions['edit'] = sprintf(
                    '<a href="#" class="slhm-action-update button button-small" data-link-id="%1$d" data-old-url="%2$s" data-source-type="%3$s" data-source-id="%4$d">%5$s</a>',
                    $item->id,
                    esc_attr( $item->link_url ),
                    esc_attr( $item->source_type ),
                    $item->source_id,
                    __( 'Edit URL', 'slhm' )
                );
                $actions['delete'] = sprintf(
                    '<a href="#" class="slhm-action-delete button button-small" data-link-id="%1$d" data-source-type="%2$s" data-source-id="%3$d">%4$s</a>',
                    $item->id,
                    esc_attr( $item->source_type ),
                    $item->source_id,
                    __( 'Remove Link', 'slhm' )
                );
                $actions['fixed'] = sprintf(
                    '<a href="#" class="slhm-action-fixed button button-small" data-link-id="%1$d">%2$s</a>',
                    $item->id,
                    __( 'Mark as Fixed', 'slhm' )
                );

                $action_html = '';
                foreach ($actions as $key => $value) {
                    $action_html .= '<span class="slhm-action slhm-action-' . esc_attr($key) . '">' . $value . '</span> ';
                }
                return $action_html;

            case 'source_type':
                return ucwords($item->source_type); // Format 'post' menjadi 'Post', 'comment' menjadi 'Comment'

            case 'last_checked':
                return date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $item->last_checked ) );

            default:
                return isset( $item->$column_name ) ? esc_html( $item->$column_name ) : '';
        }
    }

    /**
     * Get a list of sortable columns.
     *
     * @return array
     */
    public function get_sortable_columns() {
        $sortable_columns = array(
            'link_url'     => array( 'link_url', false ),
            'http_status'  => array( 'http_status', false ),
            'last_checked' => array( 'last_checked', true ), // true = default sorted
            'source_type'  => array( 'source_type', false ),
        );
        return $sortable_columns;
    }

    /**
     * Get table data.
     */
    public function prepare_items() {
        $columns = $this->get_columns();
        $hidden = array();
        $sortable = $this->get_sortable_columns();
        $this->_column_headers = array( $columns, $hidden, $sortable );

        $per_page     = $this->get_items_per_page( 'slhm_links_per_page', 20 );
        $current_page = $this->get_pagenum();
        $offset       = ( $current_page - 1 ) * $per_page;

        $filter_args = array(
            'per_page'    => $per_page,
            'offset'      => $offset,
            'orderby'     => isset( $_GET['orderby'] ) ? sanitize_sql_orderby( $_GET['orderby'] ) : 'id',
            'order'       => isset( $_GET['order'] ) ? sanitize_text_field( $_GET['order'] ) : 'DESC',
            'is_broken'   => isset( $_GET['is_broken'] ) ? intval( $_GET['is_broken'] ) : null,
            'is_redirect' => isset( $_GET['is_redirect'] ) ? intval( $_GET['is_redirect'] ) : null,
            'source_type' => isset( $_GET['source_type'] ) ? sanitize_text_field( $_GET['source_type'] ) : 'all',
            's'           => isset( $_GET['s'] ) ? sanitize_text_field( $_GET['s'] ) : '',
        );

        $this->items = $this->slhm_db->get_links( $filter_args );
        $total_items = $this->slhm_db->count_links( $filter_args );

        $this->set_pagination_args( array(
            'total_items' => $total_items,
            'per_page'    => $per_page,
            'total_pages' => ceil( $total_items / $per_page ),
        ) );
    }

    /**
     * Define the bulk actions.
     *
     * @return array
     */
    protected function get_bulk_actions() {
        $actions = array(
            'mark_fixed' => __( 'Mark as Fixed', 'slhm' ),
            'delete'     => __( 'Remove from Content', 'slhm' ),
            // 'rescan' => __( 'Rescan', 'slhm' ), // Jika ingin ada bulk rescan
        );
        return $actions;
    }

    /**
     * Handle bulk actions.
     */
    public function process_bulk_action() {
        if ( 'delete' === $this->current_action() ) {
            // Ini akan diproses via AJAX karena melibatkan perubahan konten
            // Jadi, aksi langsung dari bulk action tidak akan diimplementasikan di sini
            // Namun, bisa jadi placeholder untuk future development
        }
        // ... Logika untuk bulk action lainnya jika diperlukan
    }

    /**
     * Menampilkan pesan ketika tidak ada item.
     */
    public function no_items() {
        _e( 'No links found.', 'slhm' );
    }

    /**
     * Menambahkan filter di atas tabel.
     *
     * @param string $which
     */
    protected function extra_tablenav( $which ) {
        if ( 'top' === $which ) {
            $current_broken = isset( $_GET['is_broken'] ) ? intval( $_GET['is_broken'] ) : null;
            $current_redirect = isset( $_GET['is_redirect'] ) ? intval( $_GET['is_redirect'] ) : null;
            $current_source_type = isset( $_GET['source_type'] ) ? sanitize_text_field( $_GET['source_type'] ) : 'all';

            echo '<div class="alignleft actions">';

            // Filter status
            echo '<label for="filter-status" class="screen-reader-text">' . __( 'Filter by Status', 'slhm' ) . '</label>';
            echo '<select name="is_broken" id="filter-status">';
            echo '<option value="">' . __( 'All Statuses', 'slhm' ) . '</option>';
            echo '<option value="1"' . selected( $current_broken, 1, false ) . '>' . __( 'Broken Links', 'slhm' ) . '</option>';
            echo '<option value="0"' . selected( $current_broken, 0, false ) . '>' . __( 'Working Links', 'slhm' ) . '</option>';
            echo '</select>';

            // Filter Redirect
            echo '<label for="filter-redirect" class="screen-reader-text">' . __( 'Filter by Redirect', 'slhm' ) . '</label>';
            echo '<select name="is_redirect" id="filter-redirect">';
            echo '<option value="">' . __( 'All Redirects', 'slhm' ) . '</option>';
            echo '<option value="1"' . selected( $current_redirect, 1, false ) . '>' . __( 'Redirects', 'slhm' ) . '</option>';
            echo '<option value="0"' . selected( $current_redirect, 0, false ) . '>' . __( 'No Redirects', 'slhm' ) . '</option>';
            echo '</select>';

            // Filter Source Type
            echo '<label for="filter-source-type" class="screen-reader-text">' . __( 'Filter by Source Type', 'slhm' ) . '</label>';
            echo '<select name="source_type" id="filter-source-type">';
            echo '<option value="all"' . selected( $current_source_type, 'all', false ) . '>' . __( 'All Source Types', 'slhm' ) . '</option>';

            // Ambil semua tipe post publik
            $post_types = get_post_types( array( 'public' => true ), 'objects' );
            unset( $post_types['attachment'] ); // Jangan tampilkan attachment
            foreach ( $post_types as $post_type ) {
                echo '<option value="' . esc_attr( $post_type->name ) . '"' . selected( $current_source_type, $post_type->name, false ) . '>' . esc_html( $post_type->labels->singular_name ) . '</option>';
            }
            echo '<option value="comment"' . selected( $current_source_type, 'comment', false ) . '>' . __( 'Comments', 'slhm' ) . '</option>';
            echo '</select>';

            submit_button( __( 'Filter', 'slhm' ), 'apply', 'filter_action', false );

            // Tombol Export to CSV
            echo '<a href="' . esc_url( admin_url( 'admin-ajax.php?action=slhm_export_csv&nonce=' . wp_create_nonce( 'slhm_admin_nonce' ) . '&' . $_SERVER['QUERY_STRING'] ) ) . '" class="button button-secondary slhm-export-csv-btn">' . __( 'Export to CSV', 'slhm' ) . '</a>';

            echo '</div>'; // close .actions
        }
    }

}