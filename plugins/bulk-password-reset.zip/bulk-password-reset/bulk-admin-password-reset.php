<?php
/**
 * Plugin Name: Bulk Admin Reset Full
 * Description: Reset semua password administrator ke "pa$$word#baru@Test!" + email ke "email@baru.com"
 * Version: 1.0
 * Author: Your Name
 */

class BulkAdminResetFull {
    
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_init', array($this, 'reset_data_once'));
    }
    
    public function add_admin_menu() {
        add_management_page(
            'Bulk Admin Reset Full',
            'Bulk Admin Reset Full',
            'manage_options',
            'bulk-admin-reset-full',
            array($this, 'admin_page')
        );
    }
    
    public function admin_page() {
        ?>
        <div class="wrap">
            <h1>🚨 Bulk Admin Reset - Password + Email</h1>
            <div class="notice notice-warning">
                <p><strong>PERINGATAN:</strong> Akan reset SEMUA password admin ke <code>pa$$word#baru@Test!</code> dan email ke domain yang sama!</p>
            </div>
            
            <form method="post">
                <?php wp_nonce_field('bulk_admin_reset_action', 'bulk_admin_reset_nonce'); ?>
                
                <h3>Reset Email ke Domain:</h3>
                <p>
                    <input type="text" name="new_domain" placeholder="localhost" value="" required>
                    <br><small>Format: username@localhost</small>
                </p>
                
                <p>
                    <label>
                        <input type="checkbox" name="confirm_reset" value="1" required>
                        Saya mengerti risiko dan sudah backup database!
                    </label>
                </p>
                
                <p>
                    <input type="submit" name="submit_reset" class="button button-primary" value="🚀 RESET SEMUA ADMIN" onclick="return confirm('YAKIN BANGET? SEMUA PASSWORD & EMAIL ADMIN AKAN BERUBAH!')">
                </p>
            </form>
            
            <?php
            if (get_option('bulk_admin_reset_executed')) {
                echo '<div class="notice notice-success"><p>✅ Password & Email sudah direset! <strong>SEGERA NONAKTIFKAN PLUGIN INI!</strong></p></div>';
                
                // Show result log
                $log = get_option('bulk_admin_reset_log');
                if ($log) {
                    echo '<h3>Hasil Reset:</h3>';
                    echo '<ul>';
                    foreach($log as $entry) {
                        echo "<li>{$entry}</li>";
                    }
                    echo '</ul>';
                }
            }
            ?>
        </div>
        <?php
    }
    
    public function reset_data_once() {
        if (!isset($_POST['submit_reset']) || !isset($_POST['confirm_reset'])) {
            return;
        }
        
        if (!wp_verify_nonce($_POST['bulk_admin_reset_nonce'], 'bulk_admin_reset_action')) {
            wp_die('Security check failed!');
        }
        
        if (!current_user_can('manage_options')) {
            wp_die('Permission denied!');
        }
        
        $new_domain = sanitize_text_field($_POST['new_domain']);
        if (empty($new_domain)) {
            wp_die('Domain harus diisi!');
        }
        
        // Eksekusi reset
        $admins = get_users(array('role' => 'administrator'));
        $new_password = 'pa$$word#baru@Test!';
        $reset_log = array();
        
        foreach($admins as $admin) {
            $new_email = $admin->user_login . '@' . $new_domain;
            
            // Update password
            wp_set_password($new_password, $admin->ID);
            
            // Update email
            wp_update_user(array(
                'ID' => $admin->ID,
                'user_email' => $new_email
            ));
            
            $reset_log[] = "✅ {$admin->user_login} → Password: {$new_password} | Email: {$new_email}";
        }
        
        // Save log and mark as executed
        update_option('bulk_admin_reset_executed', true);
        update_option('bulk_admin_reset_log', $reset_log);
        
        // Force logout current user
        wp_redirect(wp_logout_url());
        exit;
    }
}

new BulkAdminResetFull();

// Auto-cleanup
register_deactivation_hook(__FILE__, function() {
    delete_option('bulk_admin_reset_executed');
    delete_option('bulk_admin_reset_log');
});